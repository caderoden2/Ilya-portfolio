# Converts attention time into visible contribution value
