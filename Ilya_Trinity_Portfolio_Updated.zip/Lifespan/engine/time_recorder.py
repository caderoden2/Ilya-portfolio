# Records time spent on each post, person, or thread
