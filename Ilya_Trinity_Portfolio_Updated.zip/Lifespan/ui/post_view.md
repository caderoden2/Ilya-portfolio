# Post UI Concept
- Share button
- 'Give a sec' = like
- Time watched = auto-logged
