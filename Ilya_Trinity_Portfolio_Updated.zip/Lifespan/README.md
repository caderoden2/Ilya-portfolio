# Lifespan – The Human Hub

Lifespan is a viral social platform with a twist:
> Everything you do is measured by the time you gave.

No likes—just “Give a sec.”  
No negativity—just silence if there’s nothing to give.

---

## System Architecture

### `engine/`
- `time_recorder.py` — tracks attention per user/post
- `contribution_meter.py` — converts time into meaningful contribution values

### `ledger/`
- `user_ledger.json` — ongoing attention record per user (given & received)

### `ui/`
- `post_view.md` — interface structure with share + give-a-sec buttons

### `activity/`
- `example_post.json` — mock post with time spent and share stats

---

## Principles

- **You give presence** by staying.  
- **You receive presence** by mattering.  
- **No one loses.** You either contribute or quietly move on.

Kelly may assist—but only when asked.

> Lifespan doesn’t chase your time. It honors it.